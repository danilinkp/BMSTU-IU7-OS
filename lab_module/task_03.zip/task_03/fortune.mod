./fortune.o
